CREATE procedure P_USER_DISTRIBUT is

begin

  --先删除,再插入
  delete from t_user_distribut;
  for rowData in (select city, count(1) / 100 as cnt
                    from T_BASE_USER t
                   group by t.city) loop
    begin
      --插入记录
      insert into t_user_distribut
        (city, city_inc)
      values
        (nvl(rowData.City,'其他'), rowData.cnt);
      commit;
    exception
      when others then
        rollback;
    end;
  end loop;

end P_USER_DISTRIBUT;

/

