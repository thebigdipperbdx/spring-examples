CREATE TRIGGER T_RESOURCELISTTOVERSION
  AFTER INSERT OR UPDATE OR DELETE
  ON TAB_RESOURCELIST
  FOR EACH ROW
  begin
  if inserting or updating then
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), c.company_code, b.usercode, sysdate, 0
        from tab_roleresource a
       inner join tab_userrole b
          on b.roleid = a.roleid
       inner join t_base_employee c
          on c.code = b.usercode
       where a.resourceid = :new.ID;
  else
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), c.company_code, b.usercode, sysdate, 0
        from tab_roleresource a
       inner join tab_userrole b
          on b.roleid = a.roleid
       inner join t_base_employee c
          on c.code = b.usercode
       where a.resourceid = :old.id;
  end if;

end T_RESOURCELISTTOVERSION;

/

