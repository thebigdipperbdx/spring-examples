CREATE PROCEDURE "GET_WK"
   IS

      v_wk   VARCHAR2 (30);
      p_date VARCHAR2 (30);
      v_n    NUMBER;
BEGIN

				SELECT TO_NUMBER (TO_CHAR (p_date, 'D'))

					INTO v_n

					FROM DUAL;



				IF v_n = 1

				THEN

					 v_wk :=

								 TO_CHAR (p_date - 6, 'YYYY/MM/DD')

							|| '-'

							|| TO_CHAR (p_date, 'YYYY/MM/DD');

				ELSE

					 v_wk :=

								 TO_CHAR (p_date + (7 - (5 + v_n)), 'YYYY/MM/DD')

							|| '-'

							|| TO_CHAR (p_date + (7 - (5 + v_n)) + 6, 'YYYY/MM/DD');

				END IF;
				RETURN v_wk;
END "GET_WK";

/

