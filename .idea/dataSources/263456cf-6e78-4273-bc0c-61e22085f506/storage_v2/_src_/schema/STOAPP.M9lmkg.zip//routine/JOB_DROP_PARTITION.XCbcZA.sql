CREATE PROCEDURE job_drop_partition IS
  V_ROW  USER_INDEXES%ROWTYPE;
  V_SQL  VARCHAR2(100);


--保留7天的分区表
BEGIN
  FOR V_ROW IN (select t.table_name,t.partition_name,
       to_date(substr(long_2_varchar(user, t.table_name, t.partition_name),11,10),'YYYY-MM-DD')
  from user_tab_partitions t
where to_date(substr(long_2_varchar(user, t.table_name, t.partition_name),11,10),'YYYY-MM-DD') <sysdate-7
and table_name in('T_LOG_EXCEPTION','T_LOG_WEB_REQUEST')
and to_date(substr(long_2_varchar(user, t.table_name, t.partition_name),11,10),'YYYY-MM-DD') >to_date('2018-01-01','YYYY-MM-DD')) LOOP
     V_SQL:= 'alter table '||V_ROW.TABLE_NAME||' drop partition '||V_ROW.partition_name||' update global indexes';
     EXECUTE IMMEDIATE V_SQL;
  END LOOP;

 END job_drop_partition;

/

