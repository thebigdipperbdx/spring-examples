CREATE procedure P_EFFICIENT(P_ID in varchar2) is
  v_IS_EFFICIENT   T_NEWS.IS_EFFICIENT%type;
  v_NEWS_THEME     T_NEWS.NEWS_THEME%type;
  v_PRO_MODULE     T_NEWS.PRO_MODULE%type;
  v_EFFECTIVE_TIME T_NEWS.EFFECTIVE_TIME%type;
  begin
    select IS_EFFICIENT, NEWS_THEME, PRO_MODULE, EFFECTIVE_TIME
    into v_IS_EFFICIENT, v_NEWS_THEME, v_PRO_MODULE, v_EFFECTIVE_TIME
    from dual
      left join (select IS_EFFICIENT,
                   NEWS_THEME,
                   PRO_MODULE,
                   EFFECTIVE_TIME,
                   'X' as A
                 from T_NEWS
                 where id = P_ID) t
        on t.A = dummy;
    --立即生效
    if v_IS_EFFICIENT=0 then
      --首页广告/寄件广告
      if nvl(v_NEWS_THEME,'*') = 'cNewsHome'  then
        update T_NEWS t set t.STATUS='2' where NEWSTYPE='1' and NEWS_THEME = 'cNewsHome' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'bNewsHome'  then
        update T_NEWS t set t.STATUS='2' where NEWSTYPE='1' and NEWS_THEME = 'bNewsHome' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'cNewsSend' then
        update T_NEWS t set t.STATUS='2' where NEWSTYPE='1' and NEWS_THEME = 'cNewsSend' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'bNewsScreen' then
        update T_NEWS t set t.STATUS='2' where NEWSTYPE='1' and NEWS_THEME = 'bNewsScreen' and t.id<>P_ID;
      end if;
      if v_NEWS_THEME = 'cNewsProducts' then
        update T_NEWS t set t.STATUS='2' where NEWSTYPE='1' and PRO_MODULE=v_PRO_MODULE and t.id<>P_ID;
      end if;
    end if;

    --不立即生效
    if v_IS_EFFICIENT=1 then
      --首页广告/寄件广告
      if nvl(v_NEWS_THEME,'*') = 'cNewsHome' then
        update T_NEWS t set t.STATUS='2' where t.EFFECTIVE_TIME<v_EFFECTIVE_TIME and NEWS_THEME = 'cNewsHome' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'bNewsHome' then
        update T_NEWS t set t.STATUS='2' where t.EFFECTIVE_TIME<v_EFFECTIVE_TIME and NEWS_THEME = 'bNewsHome' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'bNewsScreen' then
        update T_NEWS t set t.STATUS='2' where t.EFFECTIVE_TIME<v_EFFECTIVE_TIME and NEWS_THEME = 'bNewsScreen' and t.id<>P_ID;
      end if;
      if nvl(v_NEWS_THEME,'*') = 'cNewsSend' then
        update T_NEWS t set t.STATUS='2' where t.EFFECTIVE_TIME<v_EFFECTIVE_TIME and NEWS_THEME='cNewsSend' and t.id<>P_ID;
      end if;
      if v_NEWS_THEME = 'cNewsProducts' then
        update T_NEWS t set t.STATUS='2' where t.EFFECTIVE_TIME<v_EFFECTIVE_TIME and NEWSTYPE='1' and PRO_MODULE=v_PRO_MODULE and t.id<>P_ID;
      end if;
    end if;
    commit;
  end P_EFFICIENT;
/

