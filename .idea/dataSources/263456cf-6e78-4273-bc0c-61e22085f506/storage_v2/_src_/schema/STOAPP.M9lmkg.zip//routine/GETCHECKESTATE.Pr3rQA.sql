CREATE FUNCTION getcheckeState(v_rid VARCHAR2, v_resid VARCHAR2)
  RETURN VARCHAR2 IS
  result       VARCHAR2(20);
  roleresource tab_roleresource%ROWTYPE;
begin

  begin
    select *
      into roleresource
      from tab_roleresource x
     where x.roleid = v_rid
       and x.resourceid = v_resid;
  EXCEPTION
    WHEN OTHERS THEN
      roleresource := NULL;
  END;
  --记录数
  if roleresource.id is not null then
    result := 1 || '@';
  else
    result := 0 || '@';
  end if;

  --新增
  if roleresource.ist = 1 then
    result := result || '1@';
  else
    result := result || '0@';
  end if;

  --删除
  if roleresource.del = 1 then
    result := result || '1@';
  else
    result := result || '0@';
  end if;

  --修改
  if roleresource.edt = 1 then
    result := result || '1@';
  else
    result := result || '0@';
  end if;

  --启用
  if roleresource.funenable = 1 then
    result := result || '1@';
  else
    result := result || '0@';
  end if;

  return result;
END getcheckeState;

/

