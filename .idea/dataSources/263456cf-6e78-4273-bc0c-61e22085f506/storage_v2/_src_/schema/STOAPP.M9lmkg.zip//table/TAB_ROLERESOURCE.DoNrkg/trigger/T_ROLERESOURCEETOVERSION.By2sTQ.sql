CREATE TRIGGER T_ROLERESOURCEETOVERSION
  AFTER INSERT OR UPDATE OR DELETE
  ON TAB_ROLERESOURCE
  FOR EACH ROW
  declare
  v_count    number;
  v_sitename varchar2(20);
  v_usercode varchar2(20);
begin
  if inserting then
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), a.COMPANY_CODE, t.usercode, sysdate, 0
        from tab_userrole t
       inner join t_base_employee a
          on a.code = t.usercode
       where t.roleid = :new.roleid;
  elsif updating then
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), a.COMPANY_CODE, t.usercode, sysdate, 0
        from tab_userrole t
       inner join t_base_employee a
          on a.code = t.usercode
       where t.roleid = :new.roleid;
    if nvl(:new.roleid, '*_*') <> nvl(:old.roleid, '*_*') then
      insert into tab_userversionchangelist
        (id, sitecode, usercode, createdate, flag)
        select sys_guid(), a.COMPANY_CODE, t.usercode, sysdate, 0
          from tab_userrole t
         inner join t_base_employee a
            on a.code = t.usercode
         where t.roleid = :old.roleid;
    end if;
  else
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), a.COMPANY_CODE, t.usercode, sysdate, 0
        from tab_userrole t
       inner join t_base_employee a
          on a.code = t.usercode
       where t.roleid = :old.roleid;
  end if;
end T_ROLERESOURCEETOVERSION;

/

