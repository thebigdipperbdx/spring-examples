CREATE procedure P_month_tatistics is

  ACTIVE_USER_CNT   number(12, 2); --活跃用户
  ORDER_TOTAL_CNT   number(12, 2); --订单数量
  SERVICE_WORKS_CNT number(12, 2); --客服工单
  NEW_USER_CNT      number(12, 2); --新增会员

begin

  --活跃用户：同一个用户在过去三十天内，启动过5+次应用的，包括新老用户。
  select count(1)
    into ACTIVE_USER_CNT
    from T_BASE_USER x
   where x.CREATE_ON >= trunc(sysdate) - 30
     and x.CREATE_ON <= sysdate
     and (select count(1)
            from t_user_log y
           where y.CREATE_TIME >= trunc(sysdate) - 30
             and y.CREATE_TIME <= sysdate) >= 5;

  --订单数量：过去三十天内所产生的订单数量（取消订单除外）
  select count(1)
    into ORDER_TOTAL_CNT
    from t_order_info t
   where t.SYS_CREATETIME >= trunc(sysdate) - 30
     and t.SYS_CREATETIME <= sysdate
     and t.ORDER_STATUS != '取消';

  --客服工单：过去三十天内用户所产生的工单数量
  SERVICE_WORKS_CNT := 0;

  --新增会员：过去三十天内，所有产生的新的用户量
  select count(1)
    into NEW_USER_CNT
    from T_BASE_USER t
   where t.CREATE_ON >= trunc(sysdate) - 30
     and t.CREATE_ON <= sysdate;

  --产生月监控数据
  insert into t_user_monitor_month
    (CREATE_TIME, active_user, order_total, service_works, new_user, remark)
  values
    (trunc(sysdate),
     ACTIVE_USER_CNT,
     ORDER_TOTAL_CNT,
     SERVICE_WORKS_CNT,
     NEW_USER_CNT,
     to_char(trunc(sysdate) - 30, 'yyyy-MM-dd') || '至' ||
     to_char(trunc(sysdate), 'yyyy-MM-dd'));

end P_month_tatistics;

/

