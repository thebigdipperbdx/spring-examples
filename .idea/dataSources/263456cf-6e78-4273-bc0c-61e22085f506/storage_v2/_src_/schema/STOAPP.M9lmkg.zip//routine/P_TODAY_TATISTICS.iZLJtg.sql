CREATE procedure P_today_tatistics is

  ACTIVE_USER_CNT             number(12, 2); --活跃用户
  ORDER_TOTAL_CNT             number(12, 2); --订单数量
  SERVICE_WORKS_CNT           number(12, 2); --客服工单
  SERVICE_WORKS_COMPLETED_CNT number(12, 2); --已处理工单
  NEW_USER_CNT                number(12, 2); --新增会员
  CNT                         number(12, 2);
  ACTIVE_USER_inc             number(12, 2); --活跃用户,同比增长
  ORDER_TOTAL_inc             number(12, 2); --订单数量,同比增长
  SERVICE_WORKS_inc           number(12, 2); --客服工单,同比增长
  NEW_USER_inc                number(12, 2); --新增会员,同比增长
begin

  --1. 活跃用户：从当天0:00开始，截止到当前查看时间，启动过应用的所有用户，包括新老用户。
  select count(1)
      into ACTIVE_USER_CNT
      from T_BASE_USER t
     where t.CREATE_ON >= trunc(sysdate)
       and t.CREATE_ON <= sysdate
       and exists (select /*+ index(x USER_LOG_IDX1)*/
             1
              from t_user_log x
             where x.USER_ID = t.id
               and x.CREATE_TIME >= trunc(sysdate)
               and x.CREATE_TIME <= sysdate)
       and rownum <= 1;

  --2. 订单数量：从当天0:00开始，截止到当前查看时间，所产生的订单数量（取消订单除外）
  select count(1)
    into ORDER_TOTAL_CNT
    from t_order_info t
   where t.SYS_CREATETIME >= trunc(sysdate)
     and t.SYS_CREATETIME <= sysdate
     and t.ORDER_STATUS != '取消';

  --3. 客服工单：从当天0:00开始，截止到当前查看时间，用户所产生的工单数量
  SERVICE_WORKS_CNT           := 0;
  SERVICE_WORKS_COMPLETED_CNT := 0;

  --4. 新增会员：从当天0:00开始，截止到当前查看时间，所有产生的新的用户量
  select count(1)
    into NEW_USER_CNT
    from T_BASE_USER t
   where t.CREATE_ON >= trunc(sysdate)
     and t.CREATE_ON <= sysdate;

  --5. 查询昨天统计数据，计算同比增长多少
  select (ACTIVE_USER_CNT - nvl(ACTIVE_USER, 0)) / 100,
         (ORDER_TOTAL_CNT - nvl(ORDER_TOTAl, 0)) / 100,
         (SERVICE_WORKS_CNT - nvl(SERVICE_WORKS, 0)) / 100,
         (NEW_USER_CNT - nvl(NEW_USER, 0)) / 100
    into ACTIVE_USER_inc, ORDER_TOTAL_inc, SERVICE_WORKS_inc, NEW_USER_inc
    from dual a
    left join (select t.*, 'X' as A
                 from T_USER_MONITOR_today t
                where t.create_time = trunc(sysdate) - 1) b
      on a.dummy = b.A;

  --6. 插入汇总结果集,判断当天是否统计过
  select count(1)
    into CNT
    from T_USER_MONITOR_today t
   where t.create_time = trunc(sysdate);
  if CNT = 0 then
    --插入
    insert into T_USER_MONITOR_today
      (create_time,
       active_user,
       order_total,
       service_works,
       new_user,
       service_works_completed,
       active_user_increment,
       order_total_increment,
       service_works_increment,
       new_user_increment)
    values
      (trunc(sysdate),
       ACTIVE_USER_CNT,
       ORDER_TOTAL_CNT,
       SERVICE_WORKS_CNT,
       NEW_USER_CNT,
       SERVICE_WORKS_COMPLETED_CNT,
       ACTIVE_USER_inc,
       ORDER_TOTAL_inc,
       SERVICE_WORKS_inc,
       NEW_USER_inc);
  else
    --更新
    update T_USER_MONITOR_today
       set active_user             = ACTIVE_USER_CNT,
           order_total             = ORDER_TOTAL_CNT,
           service_works           = SERVICE_WORKS_CNT,
           new_user                = NEW_USER_CNT,
           service_works_completed = SERVICE_WORKS_COMPLETED_CNT,
           active_user_increment   = ACTIVE_USER_inc,
           order_total_increment   = ORDER_TOTAL_inc,
           service_works_increment = SERVICE_WORKS_inc,
           new_user_increment      = NEW_USER_inc
     where create_time = trunc(sysdate);
  end if;
end P_today_tatistics;

/

