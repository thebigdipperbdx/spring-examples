CREATE FUNCTION getEmpRoleName(emp_code IN varchar2)
  RETURN varchar2 IS
  result varchar2(2000);
BEGIN
  result := '';
  for rec in (select x.id || '@' || x.rolename as sss
                from tab_rolemanager x
               where x.id in (select /*+ index(y USERROLE_IDX2)*/
                               y.roleid
                                from tab_userrole y
                               where y.usercode = emp_code)) loop
    result := result || rec.sss || ',';
  end loop;
  if result is not null then
    result:=substr(result,0,length(result)-1);
  end if;
  RETURN result;
END;

/

