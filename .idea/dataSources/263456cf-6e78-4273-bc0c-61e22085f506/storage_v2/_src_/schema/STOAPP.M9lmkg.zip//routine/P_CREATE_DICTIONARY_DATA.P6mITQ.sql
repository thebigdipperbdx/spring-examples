CREATE procedure p_create_dictionary_data(v_owner in varchar2) is
  type data is record(
    OWNER       varchar2(20),
    TABLE_NAME  varchar2(30),
    COLUMN_NAME varchar2(30),
    DATA_TYPE   varchar2(20),
    DATA_LENGTH varchar2(10),
    NULLABLE    number(1),
    COMMENTS    varchar2(500),
    index_name  varchar2(50));
begin
  delete from dictionary_data where data_base = v_owner;
  for data in (select a.OWNER as OWNER,
                      a.TABLE_NAME as table_name,
                      a.COLUMN_NAME as column_name,
                      a.DATA_TYPE as data_type,
                      (case
                        when a.DATA_TYPE = 'NUMBER' then
                         null
                        when a.DATA_TYPE = 'DATE' then
                         null
                        else
                         DATA_LENGTH
                      end) as DATA_LENGTH,
                      (case
                        when a.NULLABLE = 'Y' then
                         1
                        when a.NULLABLE = 'N' then
                         0
                      end) as NULLABLE,
                      b.COMMENTS as comments
                 from all_tab_columns a
                inner join all_col_comments b
                   on a.owner = b.owner
                where a.TABLE_NAME = b.table_name
                  and a.COLUMN_NAME = b.column_name
                  and a.OWNER = upper(v_owner)) loop
    begin
      insert into dictionary_data
        (data_base,
         table_name,
         table_column,
         column_type,
         column_length,
         column_nullable,
         column_comment,
         table_index,
         create_date,
         index_column,
         modified_date)
      values
        (data.owner,
         data.table_name,
         data.column_name,
         data.data_type,
         data.data_length,
         data.nullable,
         data.comments,
         null,
         sysdate,
         null,
         sysdate);
    end;
  end loop;

  for data in (select table_owner, table_name, index_name, column_name
                 from all_ind_columns
                where table_OWNER = upper(v_owner)) loop
    insert into dictionary_data
      (data_base,
       table_name,
       table_column,
       column_type,
       column_length,
       column_nullable,
       column_comment,
       table_index,
       create_date,
       index_column,
       modified_date)
    values
      (data.table_owner,
       data.table_name,
       null,
       null,
       null,
       null,
       null,
       data.index_name,
       sysdate,
       data.column_name,
       sysdate);
  end loop;
  commit;
end p_create_dictionary_data;

/

