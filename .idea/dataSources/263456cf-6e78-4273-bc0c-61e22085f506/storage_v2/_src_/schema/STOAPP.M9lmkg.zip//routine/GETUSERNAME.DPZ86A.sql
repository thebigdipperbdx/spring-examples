CREATE function getUserName(f_userid   in varchar2,
                                       f_userType in varchar2)
  return varchar2 is
  result varchar2(50);
begin
  result:='';
  if f_userType = 'EMPLOYEE' then
    select t.user_name
      into result
      from t_base_employee t
     where t.id = f_userid;
  end if;
  if f_userType = 'USER' then
    select s.user_name
      into result
      from t_base_user s
     where s.id = f_userid;
  end if;
   if f_userType = 'SITE' then
    select t.user_name
      into result
      from t_base_employee t
     where t.id = f_userid;
  end if;
  return result;
end;

/

