CREATE TRIGGER T_RESOURCEMANAGETOVERSION
  AFTER INSERT OR UPDATE OR DELETE
  ON TAB_RESOURCEMANAGEMENT
  FOR EACH ROW
  begin
  if inserting or updating then
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), d.company_code, c.usercode, sysdate, 0
        from tab_resourcelist a
       inner join tab_roleresource b
          on b.resourceid = a.id
       inner join tab_userrole c
          on b.roleid = c.roleid
       inner join t_base_employee d
          on d.code = c.usercode
       where a.mid = :new.id;
  else
    insert into tab_userversionchangelist
      (id, sitecode, usercode, createdate, flag)
      select sys_guid(), d.company_code, c.usercode, sysdate, 0
        from tab_resourcelist a
       inner join tab_roleresource b
          on b.resourceid = a.id
       inner join tab_userrole c
          on b.roleid = c.roleid
       inner join t_base_employee d
          on d.code = c.usercode
       where a.mid = :old.id;
  end if;

end T_RESOURCEMANAGETOVERSION;

/

