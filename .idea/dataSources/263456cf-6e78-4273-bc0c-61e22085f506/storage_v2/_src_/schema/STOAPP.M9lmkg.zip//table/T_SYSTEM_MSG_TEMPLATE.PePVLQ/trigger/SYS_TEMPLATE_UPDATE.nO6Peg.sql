CREATE TRIGGER SYS_TEMPLATE_UPDATE
  AFTER UPDATE OR DELETE
  ON T_SYSTEM_MSG_TEMPLATE
  FOR EACH ROW
  declare
  integrity_error exception;
  errno  integer;
  errmsg char(200);

BEGIN

  IF UPDATING THEN
    --UPDATE触发
    UPDATE T_EMPLOYEE_MSG_TEMPLATE T
       SET T.CONTENT        = :NEW.CONTENT,
           T.TITLE          = :NEW.TITLE,
           T.CN_TEMPLATE_ID = :NEW.CN_TEMPLATE_ID,
           T.STATUS         = :NEW.STATUS
     WHERE T.SYS_TEMPLATE_ID = :OLD.ID;
  ELSIF DELETING THEN
    --DELETE触发
    DELETE from T_EMPLOYEE_MSG_TEMPLATE T
     WHERE T.SYS_TEMPLATE_ID = :OLD.ID;
  END IF;
exception
  when integrity_error then
    raise_application_error(errno, errmsg);
END;

/

