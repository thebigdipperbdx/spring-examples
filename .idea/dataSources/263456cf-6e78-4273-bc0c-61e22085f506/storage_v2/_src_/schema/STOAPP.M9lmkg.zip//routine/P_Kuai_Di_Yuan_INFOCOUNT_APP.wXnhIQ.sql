CREATE PROCEDURE P_快递员INFOCOUNT_APP(BEGINDATE IN VARCHAR2, --格式YYYY-MM-DD HH24:MI:S
                                               ENDDATE   IN VARCHAR2,
                                               SITENAME  IN VARCHAR2,
                                               EMPNO     IN VARCHAR2,
                                               RF        OUT SYS_REFCURSOR) IS
BEGIN
  OPEN RF FOR
    select sum(case when 签收标识=1 and nvl(签收类型,'###')<>'第三方代收' then 1 else 0 end) as SignCount,
           sum(case when 签收标识=0 and 问题件标识=1 then 1 else 0 end ) as quesCount,
           sum(case when 签收标识=1 and nvl(签收类型,'###')='第三方代收' then 1 else 0 end) as dsCount,
           0 as pjrgCount
      from (SELECT /*+index(t 网点派件监控表_IDX3)*/
             T.运单编号,
             t.签收标识,
             t.问题件标识,
             t.签收类型,
             ROW_NUMBER() OVER(PARTITION BY t.运单编号 ORDER BY t.扫描时间) RM
              FROM tab_网点派件监控表 T
             WHERE t.录入部门 = SITENAME
               AND t.扫描时间 >= TO_DATE(BEGINDATE, 'yyyy-mm-dd hh24:mi:ss')
               AND t.扫描时间 <= TO_DATE(ENDDATE, 'yyyy-mm-dd hh24:mi:ss')
               AND T.派件或收件员 = EMPNO) A
     WHERE RM = 1;
END P_快递员INFOCOUNT_APP;
/

