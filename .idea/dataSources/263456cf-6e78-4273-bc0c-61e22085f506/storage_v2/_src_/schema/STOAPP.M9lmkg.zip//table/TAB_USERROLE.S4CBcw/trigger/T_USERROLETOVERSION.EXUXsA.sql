CREATE TRIGGER T_USERROLETOVERSION
  AFTER INSERT OR UPDATE OR DELETE
  ON TAB_USERROLE
  FOR EACH ROW
  declare
  v_count    number;
  v_sitename varchar2(20);
begin
  if inserting then
    select t.COMPANY_CODE
      into v_sitename
      from dual
      left join (select COMPANY_CODE, 'X' as A
                   from t_base_employee
                  where CODE = :new.USERCODE
                    and rownum <= 1) t
        on t.A = dummy;

    if nvl(v_sitename, '*_*') <> '*_*' then
      select count(1)
        into v_count
        from tab_userversionchangelist t
       where t.createdate > sysdate - 1
         and t.sitecode = v_sitename
         and t.usercode = :new.usercode
         and nvl(t.flag, 0) = 0
         and rownum <= 2;

      if v_count < 2 then
        insert into tab_userversionchangelist
          (id, sitecode, usercode, createdate, flag)
        values
          (sys_guid(), v_sitename, :new.usercode, sysdate, 0);
      end if;
    end if;
  elsif updating then
    select t.COMPANY_CODE
      into v_sitename
      from dual
      left join (select COMPANY_CODE, 'X' as A
                   from t_base_employee
                  where CODE = :new.USERCODE
                    and rownum <= 1) t
        on t.A = dummy;

    if nvl(v_sitename, '*_*') <> '*_*' then
      select count(1)
        into v_count
        from tab_userversionchangelist t
       where t.createdate > sysdate - 1
         and t.sitecode = v_sitename
         and t.usercode = :new.usercode
         and nvl(t.flag, 0) = 0
         and rownum <= 2;

      if v_count < 2 then
        insert into tab_userversionchangelist
          (id, sitecode, usercode, createdate, flag)
        values
          (sys_guid(), v_sitename, :new.usercode, sysdate, 0);
      end if;
    end if;

    if nvl(:new.usercode, '*_*') <> nvl(:old.usercode, '*_*') then
      select t.COMPANY_CODE
        into v_sitename
        from dual
        left join (select COMPANY_CODE, 'X' as A
                     from t_base_employee
                    where CODE = :old.USERCODE
                      and rownum <= 1) t
          on t.A = dummy;

      if nvl(v_sitename, '*_*') <> '*_*' then
        select count(1)
          into v_count
          from tab_userversionchangelist t
         where t.createdate > sysdate - 1
           and t.sitecode = v_sitename
           and t.usercode = :old.usercode
           and nvl(t.flag, 0) = 0
           and rownum <= 2;

        if v_count < 2 then
          insert into tab_userversionchangelist
            (id, sitecode, usercode, createdate, flag)
          values
            (sys_guid(), v_sitename, :old.usercode, sysdate, 0);
        end if;
      end if;
    end if;
  else
    select t.COMPANY_CODE
      into v_sitename
      from dual
      left join (select COMPANY_CODE, 'X' as A
                   from t_base_employee
                  where CODE = :old.USERCODE
                    and rownum <= 1) t
        on t.A = dummy;

    if nvl(v_sitename, '*_*') <> '*_*' then
      select count(1)
        into v_count
        from tab_userversionchangelist t
       where t.createdate > sysdate - 1
         and t.sitecode = v_sitename
         and t.usercode = :old.usercode
         and nvl(t.flag, 0) = 0
         and rownum <= 2;

      if v_count < 2 then
        insert into tab_userversionchangelist
          (id, sitecode, usercode, createdate, flag)
        values
          (sys_guid(), v_sitename, :old.usercode, sysdate, 0);
      end if;
    end if;
  end if;
end T_USERROLETOVERSION;

/

