CREATE FUNCTION func_emp_dept
        (site_code    IN   T_EMPLOYEE_RATE_SET.site_code%TYPE)
 RETURN SYS_REFCURSOR
    IS
      po_result   SYS_REFCURSOR;
   BEGIN
       OPEN po_result FOR
         SELECT * FROM T_EMPLOYEE_RATE_SET WHERE site_code=site_code;
      RETURN po_result;
  END;

/

