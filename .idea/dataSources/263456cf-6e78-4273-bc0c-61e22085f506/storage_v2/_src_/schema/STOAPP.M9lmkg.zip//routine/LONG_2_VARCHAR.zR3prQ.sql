CREATE function long_2_varchar(p_table_owner    in all_tab_partitions.table_owner%type,
                                          p_table_name     in all_tab_partitions.table_name%type,
                                          p_partition_name in all_tab_partitions.partition_name%type)
  return varchar2 as
  l_high_value LONG;
begin
  select high_value
    into l_high_value
    from all_tab_partitions
   where table_owner = p_table_owner
     and table_name = p_table_name
     and partition_name = p_partition_name;

  return substr(l_high_value, 1, 4000);
end;

/

