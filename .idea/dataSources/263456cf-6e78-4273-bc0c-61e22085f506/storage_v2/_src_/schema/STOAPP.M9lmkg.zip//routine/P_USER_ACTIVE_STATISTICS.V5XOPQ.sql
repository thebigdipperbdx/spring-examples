CREATE procedure P_User_Active_Statistics(v_date in date) is
  v_begindate date;
  v_enddate   date;
begin
  v_begindate := to_date(to_char(v_date - 1, 'yyyy-mm-dd') || ' 00:00:00',
                         'yyyy-mm-dd hh24:mi:ss');
  v_enddate   := to_date(to_char(v_date - 1, 'yyyy-mm-dd') || ' 23:59:59',
                         'yyyy-mm-dd hh24:mi:ss');

  delete from tab_user_activation
   where activedate >= v_begindate
     and activedate <= v_enddate;
  commit;

  insert into tab_user_activation
    (id,
     activedate,
     source,
     activecount,
     androidcount,
     ioscount,
     sourcetype,
     createdate)
    select sys_guid(),
           trunc(v_begindate),
           source,
           count(t.total),
           sum(decode(client_type, 'android', 1, 0)) as android,
           sum(decode(client_type, 'ios', 1, 0)) as ios,
           'employee' as tablesource,
           sysdate
      from (select source, client_type, user_id, count(1) as total
              from T_EMPLOYEE_LOGIN_LOG
             where create_time >= v_begindate
               and create_time <= v_enddate
             group by source, client_type, user_id) t
     group by source
    union all
    select sys_guid(),
           trunc(v_begindate),
           source,
           count(t.total),
           sum(decode(client_type, 'android', 1, 0)) as android,
           sum(decode(client_type, 'ios', 1, 0)) as ios,
           'user' as tablesource,
           sysdate
      from (select source, client_type, user_id, count(1) as total
              from T_USER_LOGIN_LOG
             where create_time >= v_begindate
               and create_time <= v_enddate
             group by source, client_type, user_id) t
     group by source;
  commit;

exception
  when others then
    null;
end P_User_Active_Statistics;

/

