CREATE procedure pro_userversionprocess is
  v_date    tab_userversionchangelist%rowtype;
  v_count   number;
  v_mindate date;
  v_enddate date;
begin
  select min(createdate)
    into v_mindate
    from tab_userversionchangelist t
   where t.createdate > sysdate - 0.5
     and nvl(t.flag, 0) = 0;

  if nvl(v_mindate, sysdate) < sysdate then
    v_enddate := v_mindate + 5 / 24 / 60;

    for v_date in (select t.*, t.rowid
                     from tab_userversionchangelist t
                    where t.createdate >= v_mindate
                      and t.createdate <= v_enddate
                      and nvl(t.flag, 0) = 0) loop
      select count(1)
        into v_count
        from tab_userversion
       where sitename = v_date.sitecode
         and usercode = v_date.usercode
         and rownum <= 1;

      if v_count > 0 then
        update tab_userversion t
           set UVERSION = substr(cast(dbms_random.value as varchar2(38)),
                                 3,
                                 8)
         where sitename = v_date.sitecode
           and usercode = v_date.usercode;
      else
        insert into tab_userversion
          (sitename, usercode, UVERSION)
        values
          (v_date.sitecode,
           v_date.usercode,
           substr(cast(dbms_random.value as varchar2(38)), 3, 8));
      end if;

      delete tab_userversionchangelist where rowid = v_date.rowid;
    end loop;
  end if;
end pro_userversionprocess;

/

