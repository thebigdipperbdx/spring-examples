CREATE procedure P_自动删除无效用户 is

begin
  delete from tab_userrole x
   where not exists
   (select 1 from t_base_employee y where y.code = x.usercode);

  --同步新增员工
  insert into tab_userversionchangelist
    (id, sitecode, usercode, createdate, flag)
    select sys_guid(), company_code, code, sysdate, 0
      from t_base_employee t
     where enabled = 1
       and not exists (select 1
              from tab_userversion a
             where a.usercode = t.code
               and a.sitename = t.company_code
               and rownum <= 1);

end P_自动删除无效用户;

/

